//
//  ZUXRuntime.h
//  ZUtilsX
//
//  Created by Char Aznable on 15/11/17.
//  Copyright © 2015年 org.cuc.n3. All rights reserved.
//

#ifndef ZUtilsX_ZUXRuntime_h
#define ZUtilsX_ZUXRuntime_h

#import <Foundation/Foundation.h>
#import "zobjc.h"

ZUX_EXTERN NSString *ZUX_GetPropertyClassName(Class cls, NSString *propertyName);

#endif /* ZUtilsX_ZUXRuntime_h */
